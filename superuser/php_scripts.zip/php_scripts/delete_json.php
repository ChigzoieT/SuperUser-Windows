<?php
// Database connection details
$host     = 'localhost';
$username = 'your_username';
$password = 'your_password';
$database = 'your_database';

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    header('Content-Type: application/json');
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Get the raw JSON input
$jsonInput = file_get_contents('php://input');
$data = json_decode($jsonInput, true);

// Check if 'userkey' is provided in the JSON payload
if (isset($data['userkey'])) {
    // Use the 'userkey' from the JSON payload as the json_key in the database
    $jsonKey = $data['userkey'];
    
    // Prepare the SQL statement to retrieve json_value for the given json_key
    $query = "SELECT json_value FROM json_table WHERE json_key = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        header('Content-Type: application/json');
        die(json_encode(["error" => "Prepare failed: " . $conn->error]));
    }
    
    $stmt->bind_param('s', $jsonKey);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Decode the existing json_value
        $jsonData = json_decode($row['json_value'], true);
        
        if (json_last_error() === JSON_ERROR_NONE) {
            // Set text and file to null
            $jsonData['text'] = null;
            $jsonData['file'] = null;
            
            // Encode the modified JSON data
            $newJsonValue = json_encode($jsonData);
            
            // Prepare the SQL statement to update json_value
            $updateQuery = "UPDATE json_table SET json_value = ? WHERE json_key = ?";
            $updateStmt = $conn->prepare($updateQuery);
            if (!$updateStmt) {
                header('Content-Type: application/json');
                die(json_encode(["error" => "Prepare failed: " . $conn->error]));
            }
            
            $updateStmt->bind_param('ss', $newJsonValue, $jsonKey);
            
            // Set the content type to JSON
            header('Content-Type: application/json');
            
            if ($updateStmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Text and file set to null."]);
            } else {
                echo json_encode(["error" => "Update failed: " . $updateStmt->error]);
            }
            
            $updateStmt->close();
        } else {
            echo json_encode(["error" => "Failed to decode JSON data."]);
        }
    } else {
        echo json_encode(["error" => "No record found for the provided userkey."]);
    }
    
    $stmt->close();
} else {
    // Required parameter 'userkey' is missing
    header('Content-Type: application/json');
    echo json_encode(["error" => "Missing required parameter 'userkey'."]);
}

$conn->close();
?>
