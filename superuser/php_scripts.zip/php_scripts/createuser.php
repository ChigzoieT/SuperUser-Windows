<?php
// Database connection details
$host = 'localhost';
$username = 'your_username';
$password = 'your_password';
$database = 'your_database';

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve JSON data from POST request
$jsonData = file_get_contents('php://input');
$data = json_decode($jsonData, true);

// Check if JSON contains 'userkey', 'password', and 'state'
if (isset($data['userkey'], $data['password'], $data['state'])) {
    $userkey = $data['userkey'];
    $password = $data['password'];  // No hashing needed for verification
    $state = $data['state'];

    if ($state == "new") {
        // Check if the userkey already exists
        $checkQuery = "SELECT COUNT(*) as count FROM users WHERE userkey = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param('s', $userkey);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        if ($row['count'] > 0) {
            echo "Userkey '$userkey' already exists.\n";
        } else {
            // Insert new user into users table
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $insertQuery = "INSERT INTO users (userkey, password, currentvalue) VALUES (?, ?, 0)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param('ss', $userkey, $hashedPassword);

            if ($stmt->execute()) {
                echo "User account created successfully.\n";

                // Insert JSON data with userkey+0
                $jsonKey = $userkey . "0";
                $jsonValue = json_encode([
                    "text" => $data['cmptext'] ?? "",
                    "file" => null,
                    "filename" => null  // Explicitly setting filename to null
                ]);

                $insertJsonQuery = "INSERT INTO json_table (json_key, json_value) VALUES (?, ?)";
                $stmt->close();
                $stmt = $conn->prepare($insertJsonQuery);
                $stmt->bind_param('ss', $jsonKey, $jsonValue);

                if ($stmt->execute()) {
                    echo "JSON data stored successfully.\n";
                } else {
                    echo "Error inserting JSON data: " . $stmt->error . "\n";
                }
            } else {
                echo "Error creating user: " . $stmt->error . "\n";
            }
            $stmt->close();
        }
    } elseif ($state == "old") {
        // Authenticate user and retrieve currentvalue
        $checkQuery = "SELECT password, currentvalue FROM users WHERE userkey = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param('s', $userkey);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        if ($row && password_verify($password, $row['password'])) {
            echo "success\n";
            echo "currentvalue: " . $row['currentvalue'] . "\n";
        } else {
            echo "fail\n";
        }
    } else {
        echo "Invalid state value.\n";
    }
} else {
    echo "Missing parameters.\n";
}

// Close connection
$conn->close();
?>
